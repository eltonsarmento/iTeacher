pagarme-php
===========

Pagar.me's PHP API

[![Build Status](https://travis-ci.org/pagarme/pagarme-php.png?branch=master)](https://travis-ci.org/pagarme/pagarme-php)
