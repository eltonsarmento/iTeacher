<?php

class PagarMe_Customer extends PagarMe_Model {
}

?>
